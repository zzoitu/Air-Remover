import os
import logging
from pydub import AudioSegment
from pydub.silence import split_on_silence

logging.basicConfig(filename='error_log.txt', level=logging.INFO)

try:
    input_file = input("Enter the input file path: ")

    if not os.path.exists(input_file):
        raise FileNotFoundError("Input file not found.")

    output_format = input("Enter the output format (e.g., mp3, wav): ")

    if output_format.lower() not in ["mp3", "wav"]:
        raise ValueError("Output format not supported.")

    logging.info('Loading audio file...')

    audio = AudioSegment.from_file(input_file)

    logging.info('Splitting on silence...')

    chunks = split_on_silence(audio, min_silence_len=1000, silence_thresh=-50)

    logging.info('Combining chunks...')

    combined = AudioSegment.empty()
    for i, chunk in enumerate(chunks):
        combined += chunk
        logging.info(f'Processed chunk {i+1}/{len(chunks)}')

    output_file = "output." + output_format
    logging.info('Saving result...')

    combined.export(output_file, format=output_format)
    logging.info('Processing complete. (audio only)')

except FileNotFoundError as fnf_err:
    logging.error(str(fnf_err))
except ValueError as val_err:
    logging.error(str(val_err))
except Exception as e:
    logging.error("An error occurred", exc_info=True)
